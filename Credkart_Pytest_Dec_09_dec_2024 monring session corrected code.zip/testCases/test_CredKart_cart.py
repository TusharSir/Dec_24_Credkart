# login
# add product in wish list
# verify same product is in cart list
# your task