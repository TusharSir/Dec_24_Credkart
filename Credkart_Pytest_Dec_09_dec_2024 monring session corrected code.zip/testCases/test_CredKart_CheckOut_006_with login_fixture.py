import pytest
from selenium.webdriver.common.by import By

from pageObjects.CheckOut_Page import CheckOut_class
from utilities.Logger import log_generator_class
from utilities.ReadConfig import ReadConfigClass


@pytest.mark.usefixtures("driver_setup")
class Test_CredKart_CheckOut_006:
    # Reading the data from the config file
    email = ReadConfigClass.geta_data_for_email()
    password = ReadConfigClass.geta_data_for_password()
    login_url = ReadConfigClass.get_login_url()
    homepage_url = ReadConfigClass.get_homepage_url()
    registration_url = ReadConfigClass.get_register_url()

    key1 = ReadConfigClass.section1_data()

    # Initializing the logger, called loggen_method from loggenerator class in utitlties folder
    log = log_generator_class.loggen_method()
    driver = None

    #@pytest.mark.skipif(not TestCase_Status.get_status("test_verify_CredKart_Url_001"),reason="test_verify_CredKart_Url_001 is failed")
    def test_CheckOut_009(self, login_fixture):
        self.cc = CheckOut_class(self.driver)
        self.log.info("Testcase test_CheckOut_008 is started")
        """Test verify_user_login method with valid credentials."""
        self.log.info("Opening Browser")
        self.log.info("Click on Mac book pro")
        self.log.info("Click on add to cart")
        self.log.info("Click on proceed to checkout")
        self.cc.Click_macbookpro()
        self.log.info(" Enter First name")
        self.cc.Enter_Firstname("Credence")
        self.log.info(" Enter Last name")
        self.cc.Enter_Lastname("Credence")
        self.log.info(" Enter Phone")
        self.cc.Enter_Phone("1234567890")
        self.log.info(" Enter Address")
        self.cc.Enter_Address("Pune, Maharashtra, India, Earth")
        self.log.info(" Enter Zipcode")
        self.cc.Enter_Zipcode("411413")
        self.log.info(" Select State")
        self.cc.Select_State("Delhi")
        self.log.info(" Enter Owner")
        self.cc.Enter_Owner("Credence")
        self.log.info(" Enter CVV")
        self.cc.Enter_CVV("043")
        self.log.info(" Enter Card Number")
        self.cc.Enter_CardNumber("5281")
        self.cc.Enter_CardNumber("0370")
        self.cc.Enter_CardNumber("4891")
        self.cc.Enter_CardNumber("6168")
        self.log.info(" Select Year")
        self.cc.Select_Year("2025")
        self.log.info(" Select Month")
        self.cc.Select_Month("May")
        self.log.info("Click on checkout")
        self.cc.Click_Checkout()
        self.log.info("Verifying success message")
        #additional_utilities_class.explicit_wait(self.driver, (By.XPATH, self.cc.success_message_xpath), 10)
        if self.cc.Verify_Success_Message() == "Your order has been placed successfully.":
            print(f"Order Number is : {self.cc.Get_Order_Number()}")
            additional_utilities_class.take_screenshot(self.driver, "test_CheckOut_008", "Pass")
            assert True
        else:
            additional_utilities_class.take_screenshot(self.driver, "test_CheckOut_008", "Pass")
            assert False
