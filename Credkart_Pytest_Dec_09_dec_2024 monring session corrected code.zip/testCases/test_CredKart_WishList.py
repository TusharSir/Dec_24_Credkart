# your task

# login
# add product in wish list
# verify same product is in wish list
#